import xbmcaddon
import xbmcgui
 
addon       = xbmcaddon.Addon()
addonname   = addon.getAddonInfo('name')
 
line1 = "change this text"
line2 = "We can write anything we want here"
line3 = "disclaimer,warning,etc"
 
xbmcgui.Dialog().ok(addonname, line1, line2, line3)
